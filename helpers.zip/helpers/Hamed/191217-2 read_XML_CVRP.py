

import xml.etree.ElementTree as ET
import re
import glob, os


def key_func(x):
        return os.path.split(x)[-1]
for infile in sorted(glob.glob(os.path.join('*.xml')), key=key_func):
# for infile in sorted(glob.glob(os.path.join( '*.xml'))):
    print "Current File Being Processed is: " + infile
    tree = ET.parse(infile)
    root = tree.getroot()

    # datasetname=root.dataset
    # datasetname=dataset.text
    # print(datasetname)
    # name=root.iter('name')
    # print(dataset.text)
#Finding the number of nodes
    j=0;
    for quantity in root.iter('quantity'):
        j=j+1;
    print(j);
    N=j;
    
#Demands
    demands =[{} for x in range( N ) ];
    i=0;
    for quantity in root.iter('quantity'):
        demands[i]=float(quantity.text);
        i=i+1;
    print(demands);
    
#Depot position and nodes positions (depot in posx[0] and posy[0])
    #posx
    posx =[{} for x in range( N+1 ) ];
    posy =[{} for x in range( N +1) ];
    i=0;
    for cx in root.iter('cx'):
        posx[i]=float(cx.text);
        i=i+1;
    print(posx)

    #posy
    i=0;
    for cy in root.iter('cy'):
        posy[i]=float(cy.text);
        i=i+1;
    print(posy)


#def read_XML_CVRP(file_name):

    
    
#    return ProblemDefinition(N, points, dd_points, demands, D, C, edge_weight_type)
 