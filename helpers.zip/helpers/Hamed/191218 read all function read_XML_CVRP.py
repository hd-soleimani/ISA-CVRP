

import xml.etree.ElementTree as ET
import re
import glob, os
from helpers.cvrp_rkm16_io import calculate_D
from collections import namedtuple

def read_XML_CVRP(file_name):
    def key_func(x):
            return os.path.split(x)[-1]
    for infile in sorted(glob.glob(os.path.join('*.xml')), key=key_func):
    # for infile in sorted(glob.glob(os.path.join( '*.xml'))):
        print "Current File Being Processed is: " + infile
        tree = ET.parse(infile)
        root = tree.getroot()
    
        edge_weight_type='EUC_2D';
    #Dataset
        for dataset in root.iter('dataset'):
            print(dataset.text);
            
    #Name
        for name in root.iter('name'):
            print(name.text);       
    
    #Capacity
        for capacity in root.iter('capacity'):
            C=float(capacity.text);
            print(C);
       
    #Finding the number of nodes
        j=0;
        for quantity in root.iter('quantity'):
            j=j+1;
        print(j);
        N=j;
        
    #Demands
        demands =[{} for x in range( N+1 ) ];
        i=1;
        for quantity in root.iter('quantity'):
            demands[i]=float(quantity.text);
            i=i+1;
        demands[0]=0;
        print(demands);
        
    #Depot position and nodes positions (depot in posx[0] and posy[0])
        #posx
        posx =[{} for x in range( N+1 ) ];
        posy =[{} for x in range( N+1) ];
        i=0;
        for cx in root.iter('cx'):
            posx[i]=float(cx.text);
            i=i+1;
    #    print(posx)
    
        #posy
        i=0;
        for cy in root.iter('cy'):
            posy[i]=float(cy.text);
            i=i+1;
    #    print(posy)
    
    #Coordinations
        points=[];
        for i in range( N+1 ):
            one = posx[i]
            two = posy[i]
            points.append((one, two))
    #    points=[[posx],[posy]]
        print(points)
        dd_points=points    
    
    #Distance Matrix
        D=calculate_D(points, None, edge_weight_type )
        print(D)
    #
    namedtuple('AdditionalConstraints',
    'vehicle_count_constraint maximum_route_cost_constraint service_time_at_customer')
    ProblemDefinition = namedtuple('ProblemDefinition',
    ['size', 'coordinate_points', 'display_coordinate_points',
     'customer_demands', 'distance_matrix', 'capacity_constraint', 'edge_weight_type'])        
        
    return ProblemDefinition(N, points, dd_points, demands, D, C, edge_weight_type)
 